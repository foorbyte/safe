package com.didomultiservice.ecollect.ecollect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcollectApplicationTests {

	@Test
	void contextLoads() {
	}

}
